<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_DiscountLineDetail extends QuickBooks_IPP_Object
{
	
}
