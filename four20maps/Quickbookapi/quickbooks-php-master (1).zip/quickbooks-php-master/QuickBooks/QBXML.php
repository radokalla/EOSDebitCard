<?php

class QuickBooks_QBXML
{
	const LOCALE_UNITED_STATES = 'US';
	const LOCALE_US = 'US';

	const LOCALE_CANADA = 'CA';
	const LOCALE_CA = 'CA';
	
	const LOCALE_UNITED_KINGDOM = 'UK';
	const LOCALE_UK = 'UK';

	const LOCALE_AUSTRALIA = 'AU';
	const LOCALE_AU = 'AU';
	
	const LOCALE_ONLINE_EDITION = 'OE';
	const LOCALE_OE = 'OE';
	
}