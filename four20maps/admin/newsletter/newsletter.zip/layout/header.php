<html>
<head>
	<title><?php echo _l('Newsletter System');?><?php echo ($page_title)?' :: '._l($page_title):'';?></title>
	<script language="javascript" src="layout/js/jquery.js"></script>
	<script language="javascript" src="layout/js/jquery.flot.js"></script>
	<script language="javascript" src="layout/js/javascript.js"></script>
	<!--[if IE]><script language="javascript" type="text/javascript" src="layout/js/excanvas.js"></script><![endif]-->
	<link rel="stylesheet" href="layout/css/styles.css" type="text/css" />
</head>
<body>

